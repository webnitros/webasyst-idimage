<?php

return array(
    'php.curl' => [
        'name' => 'cURL',
        'description' => 'Обмен данными со сторонними серверами',
        'strict' => true,
    ],
    'php' => [
        'strict' => true,
        'version' => '>=7.4',
    ],
);
