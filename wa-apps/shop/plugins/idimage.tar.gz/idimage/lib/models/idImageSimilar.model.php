<?php

class idImageSimilarModel extends waModel
{
    protected $table = 'shop_idimage_similars';
}
