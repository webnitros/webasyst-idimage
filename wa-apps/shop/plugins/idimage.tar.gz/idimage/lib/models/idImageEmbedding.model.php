<?php

class idImageEmbeddingModel extends waModel
{
    protected $table = 'shop_idimage_embeddings';
}
